# -*- coding: utf-8 -*-
#开发人员：zhoucj

import requests
from lxml import etree
import re
import time


header = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36"}

#url="http://www.xinbqg.com/0/455/"
print("1、请到新笔趣阁查找喜欢的小说：http://www.xinbqg.com")

num=str(input("2、输入小说编号（网址后面的数字,如/0/455/）："))
url="http://www.xinbqg.com"+num
html=requests.get(url,headers=header).text
etree_html=etree.HTML(html)
Mulist = etree_html.xpath('//dd/a')
title = etree_html.xpath('//div/h1')
title=str(title[0].text)
print("3、准备下载："+title)
time.sleep(3)


i=0
for i in range(0,len(Mulist)):
    mulist = Mulist[i].text
    print("正在下载:"+mulist)

    Nrlist = etree_html.xpath('//dd/a/@href')
    nrurl = "http://www.xinbqg.com" + Nrlist[i]
    html2 = requests.get(nrurl, headers=header).text
    pat=r'&nbsp;&nbsp;&nbsp;&nbsp;'
    pat2=r'<br /><br />'
    html2=re.sub(pat,'',html2)
    html2 = re.sub(pat2, '\n', html2)
    etree_html2 = etree.HTML(html2)
    Nrlist2 = etree_html2.xpath('//div[@id="content"]')
    NR=Nrlist2[0].text
    with open('./小说/'+title+'.txt', 'a+') as f:
        f.write(mulist)
        f.write('\n')
        f.write(NR)
        f.write('\n''\n')

print("____________________________________________")
print("_*_下载完成_*_")
print("_*_保存在我的文档_*_")

