#import urllib.request
from urllib import request
import re
import random

url=r"http://www.baidu.com/"

#伪装多个浏览器的ser-Agent
agent1="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36"
agent2="Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0"
agent3="Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0;"
agent4="Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1"
agent5="Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)"
list1=[agent1,agent2,agent2,agent3,agent5]
agent=random.choice(list1)
#print(agent)


#构造请求头信息
header={"User-Agent":agent }

#创建自定义请求对象
req=request.Request(url,headers=header)
#反爬虫机制1：判断用户是否是浏览器访问
#可以通过伪装浏览器进行访问，headers


#发送请求，获取响应信息
reponse=request.urlopen(req).read().decode() #解码---（编码encode())
pat=r"<title>(.*?)</title>"  #正则表达式
date=re.findall(pat,reponse)
print(date[0])