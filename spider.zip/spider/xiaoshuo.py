#coding:utf-8
import urllib.request
url="http://www.bxquge.com/3_3619/10826.html"
headers = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36"}
request =urllib.request.Request(url,headers=headers)
response = urllib.request.urlopen(request)
html=response.read().decode("utf-8")
print(html)