# -*- coding: utf-8 -*-
#开发人员：zhoucj

from bs4 import BeautifulSoup
import requests


header = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0",
          "Referer":"https://www.mzitu.com/jiepai/comment-page-1/",}
url = 'https://www.mzitu.com/jiepai/comment-page-{}/#comments'
name = 0



html = requests.get(url,headers=header).text

soup= BeautifulSoup(html,"lxml")
#print(soup)
print(soup.title)
print(soup.title.string)    #获取标签内容
print(soup.title.name)      #获取标签名
print(soup.script.attrs)     #获取标签的所有属性
print(soup.script.attrs["src"])  #获取标签内的属性的内容
print(soup.head.contents)       #获取直接子标签，结果是一个列表
#print(soup.descendants)     #获取所有子标签结果是一个生成器
#for i in soup.head.descendants:
    #print(i)