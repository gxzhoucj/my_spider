from urllib import request
import random

#反爬虫2：判断请求来源的ip地址
#措施使用代理ip

#115.219.111.35	8010

proxylist=[
    {"http":"115.219.111.35:8010"},
    {"http":"115.219.111.35:8010"},
    {"http":"115.219.111.35:8010"},
    {"http":"115.219.111.35:8010"},
    {"http":"115.219.111.35:8010"},
    {"http":"115.219.111.35:8010"},
    {"http":"116.208.54.61:9999"},
]

proxy=random.choice(proxylist)

#构建代理处理器对象
proxyHandler=request.ProxyHandler(proxy)


#创建算定义opener
opener=request.build_opener(proxyHandler)

#创建请求对象
req=request.Request("http://www.baidu.com")

res=opener.open(req)

print(res.read().edcode())
